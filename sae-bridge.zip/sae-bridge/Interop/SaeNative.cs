using System.Runtime.InteropServices;
using System.Text;

namespace SaeBridge.Interop;

/// <summary>
/// P/Invoke declarations for InterfaseSae70.dll (native Delphi DLL).
/// 
/// REFACTOR DECISION (Flat Functions / Interop Wrapper):
/// Instead of calling decorated __fastcall class methods (which cause 0xC0000005 Access Violation 
/// because of standard .NET stack mapping vs Delphi register expectations), we utilize 
/// the un-mangled FLAT dispatch functions exported by Aspel engineers for external systems.
/// 
/// All calls go through EjecutaComando or EjecutaComandoXE (for Unicode/XE environments) 
/// using standard StdCall convention and ANSI CharSet, passing normal strings.
/// </summary>
public static class SaeNative
{
    private const string DLL_PATH = @"C:\Program Files (x86)\Aspel\Aspel-SAE 9.0\InterfaseSae70.dll";

    /// <summary>
    /// Executes a SAE command by name using standard ANSI strings.
    /// Maps to flat C export: EjecutaComando
    /// </summary>
    [DllImport(DLL_PATH, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int EjecutaComando(
        string nombreComando,
        string xmlInput,
        StringBuilder xmlOutput
    );

    /// <summary>
    /// Executes a SAE command by name (XE Unicode variant).
    /// Maps to flat C export: EjecutaComandoXE
    /// </summary>
    [DllImport(DLL_PATH, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int EjecutaComandoXE(
        string nombreComando,
        string xmlInput,
        StringBuilder xmlOutput
    );

    /// <summary>
    /// Executes a SAE command by name (XE Mobile variant).
    /// Maps to flat C export: EjecutaComandoXE_Movil
    /// </summary>
    [DllImport(DLL_PATH, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int EjecutaComandoXE_Movil(
        string nombreComando,
        string xmlInput,
        StringBuilder xmlOutput
    );

    /// <summary>
    /// Executes a SAE command by name (Bridge variant).
    /// Maps to flat C export: EjecutaComandoPuente
    /// </summary>
    [DllImport(DLL_PATH, CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
    public static extern int EjecutaComandoPuente(
        string nombreComando,
        string xmlInput,
        StringBuilder xmlOutput
    );
}
