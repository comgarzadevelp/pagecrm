using System.Text;

namespace SaeBridge.Interop;

/// <summary>
/// Manages the SAE session lifecycle and provides thread-safe access to the DLL.
/// 
/// ARCHITECTURE DECISIONS:
/// 1. The Delphi DLL is NOT thread-safe → ALL calls are serialized via SemaphoreSlim.
/// 2. The session is initialized ONCE at startup and kept alive via ContinuaIntSAE.
/// 3. The session is terminated ONLY when the service shuts down.
/// 4. Communication uses the flat dispatch functions (EjecutaComando/EjecutaComandoXE) to prevent memory crashes.
/// </summary>
public class SaeSessionManager : IDisposable
{
    private readonly SemaphoreSlim _semaphore = new(1, 1);
    private bool _isInitialized = false;
    private Timer? _keepAliveTimer;
    private readonly ILogger<SaeSessionManager> _logger;
    private readonly SaeConfig _config;

    public bool IsInitialized => _isInitialized;
    public string LastError { get; private set; } = string.Empty;
    public string LastSaeResponse { get; private set; } = string.Empty;

    public SaeSessionManager(ILogger<SaeSessionManager> logger, SaeConfig config)
    {
        _logger = logger;
        _config = config;
    }

    /// <summary>
    /// Global dispatcher helper to call any command via flat Delphi exports.
    /// serializes P/Invoke string buffers safely.
    /// </summary>
    public static int DispatchSaeCommand(string commandName, string xmlInput, out string xmlOutput)
    {
        var sb = new StringBuilder(1024 * 1024); // 1 MB buffer for response XML
        int result;
        
        try
        {
            // We use EjecutaComandoXE which is designed for XE (Unicode-compliant) environments
            result = SaeNative.EjecutaComandoXE(commandName, xmlInput, sb);
        }
        catch
        {
            try
            {
                // Fallback to traditional EjecutaComando
                sb.Clear();
                result = SaeNative.EjecutaComando(commandName, xmlInput, sb);
            }
            catch (Exception ex)
            {
                xmlOutput = $"Exception in P/Invoke flat wrapper: {ex.Message}";
                return -999;
            }
        }
        
        xmlOutput = sb.ToString();
        return result;
    }

    /// <summary>
    /// Initializes the SAE session. Called once at application startup.
    /// Constructs the XML input that SAE expects for initialization.
    /// </summary>
    public async Task<bool> InitializeAsync()
    {
        await _semaphore.WaitAsync();
        try
        {
            if (_isInitialized)
            {
                _logger.LogWarning("SAE session already initialized");
                return true;
            }

            _logger.LogInformation("Initializing SAE session via Flat Command Dispatcher...");
            _logger.LogInformation("  Data Path: {Path}", _config.RutaDatos);
            _logger.LogInformation("  User: {User}", _config.Usuario);
            _logger.LogInformation("  Company: {Empresa}", _config.NumEmpresa);

            string xmlInput = $@"<?xml version=""1.0"" encoding=""UTF-8""?>
<DATAPACKET>
  <ROWDATA>
    <ROW RutaDatos=""{_config.RutaDatos}"" 
         Usuario=""{_config.Usuario}"" 
         Password=""{_config.Password}"" 
         NumEmpresa=""{_config.NumEmpresa}"" />
  </ROWDATA>
</DATAPACKET>";

            string xmlOutput;
            int result;

            try
            {
                _logger.LogInformation("Sending 'IniciaInterfazSAESinLogin' command...");
                result = DispatchSaeCommand("IniciaInterfazSAESinLogin", xmlInput, out xmlOutput);
                _logger.LogInformation("Command returned code: {Code}", result);
                _logger.LogDebug("SAE Response XML: {Xml}", xmlOutput);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "SinLogin command dispatch failed, trying standard IniciaInterfazSAE...");
                try
                {
                    result = DispatchSaeCommand("IniciaInterfazSAE", xmlInput, out xmlOutput);
                    _logger.LogInformation("Command returned code: {Code}", result);
                }
                catch (Exception ex2)
                {
                    LastError = $"Both init attempts failed: {ex.Message} | {ex2.Message}";
                    _logger.LogError("All SAE initialization attempts failed");
                    return false;
                }
            }

            LastSaeResponse = xmlOutput;

            if (result == 0)
            {
                _isInitialized = true;
                LastError = string.Empty;
                _logger.LogInformation("✅ SAE session initialized successfully!");

                // Start keep-alive timer (every 5 minutes)
                _keepAliveTimer = new Timer(KeepAliveCallback, null,
                    TimeSpan.FromMinutes(5),
                    TimeSpan.FromMinutes(5));

                return true;
            }
            else
            {
                LastError = $"SAE init returned code: {result}. Response: {xmlOutput}";
                _logger.LogError("SAE initialization failed. Code: {Code}, Response: {Response}", result, xmlOutput);
                return false;
            }
        }
        finally
        {
            _semaphore.Release();
        }
    }

    /// <summary>
    /// Executes a SAE command in a thread-safe serialized manner.
    /// </summary>
    public async Task<(int code, string response)> ExecuteSaeAsync(
        string commandName,
        string xmlInput)
    {
        if (!_isInitialized)
        {
            throw new InvalidOperationException(
                "SAE session is not initialized. POST /api/sae/init to initialize.");
        }

        await _semaphore.WaitAsync();
        try
        {
            _logger.LogDebug("Dispatching SAE operation: {Command}", commandName);
            string xmlOutput;
            int code = DispatchSaeCommand(commandName, xmlInput, out xmlOutput);
            _logger.LogDebug("SAE operation {Command} completed with code: {Code}", commandName, code);
            return (code, xmlOutput);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "SAE operation {Command} failed", commandName);
            throw;
        }
        finally
        {
            _semaphore.Release();
        }
    }

    /// <summary>
    /// Keep-alive callback — calls ContinuaIntSAE to prevent session timeout.
    /// </summary>
    private void KeepAliveCallback(object? state)
    {
        if (!_isInitialized) return;

        _semaphore.Wait();
        try
        {
            string output;
            var result = DispatchSaeCommand("ContinuaIntSAE", "", out output);
            if (result != 0)
            {
                _logger.LogWarning("ContinuaIntSAE returned: {Code}. Response: {Response}", result, output);
            }
            else
            {
                _logger.LogDebug("SAE keep-alive ping successful");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "SAE keep-alive failed");
        }
        finally
        {
            _semaphore.Release();
        }
    }

    /// <summary>
    /// Gracefully terminates the SAE session.
    /// </summary>
    public void Dispose()
    {
        _keepAliveTimer?.Dispose();

        if (_isInitialized)
        {
            _semaphore.Wait();
            try
            {
                _logger.LogInformation("Terminating SAE session...");
                string output;
                DispatchSaeCommand("TerminaInterfazSAE", "", out output);
                _isInitialized = false;
                _logger.LogInformation("SAE session terminated. Response: {Response}", output);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error terminating SAE session");
            }
            finally
            {
                _semaphore.Release();
            }
        }

        _semaphore.Dispose();
    }
}

/// <summary>
/// Configuration for the SAE connection.
/// Loaded from appsettings.json → "Sae" section.
/// </summary>
public class SaeConfig
{
    public string RutaDatos { get; set; } = @"C:\Program Files (x86)\Aspel\Aspel-SAE 9.0\";
    public string Usuario { get; set; } = "";
    public string Password { get; set; } = "";
    public int NumEmpresa { get; set; } = 1;
}
